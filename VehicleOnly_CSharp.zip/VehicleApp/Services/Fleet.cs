
using System.Collections.Generic;

namespace VehicleApp.Services
{
    public class Fleet
    {
        private List<Garage> garages = new List<Garage>();

        public void AddGarage(Garage g)
        {
            garages.Add(g);
            System.Console.WriteLine("Гараж қосылды");
        }

        public Garage GetGarage(int index)
        {
            return garages[index];
        }
    }
}
