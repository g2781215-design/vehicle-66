
using System.Collections.Generic;
using VehicleApp.Models;

namespace VehicleApp.Services
{
    public class Garage
    {
        private List<Vehicle> vehicles = new List<Vehicle>();

        public void AddVehicle(Vehicle v)
        {
            vehicles.Add(v);
            System.Console.WriteLine("Көлік гаражға қосылды");
        }

        public void RemoveVehicle(int index)
        {
            if (index >= 0 && index < vehicles.Count)
            {
                vehicles.RemoveAt(index);
                System.Console.WriteLine("Көлік гараждан өшірілді");
            }
        }

        public void ShowVehicles()
        {
            foreach (var v in vehicles)
            {
                v.Info();
            }
        }
    }
}
