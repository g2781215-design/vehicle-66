
namespace VehicleApp.Models
{
    public class Vehicle
    {
        protected string Brand;
        protected string Model;
        protected int Year;

        public Vehicle(string brand, string model, int year)
        {
            Brand = brand;
            Model = model;
            Year = year;
        }

        public virtual void StartEngine()
        {
            System.Console.WriteLine($"{Brand} {Model}: қозғалтқыш іске қосылды");
        }

        public virtual void StopEngine()
        {
            System.Console.WriteLine($"{Brand} {Model}: қозғалтқыш тоқтатылды");
        }

        public virtual void Info()
        {
            System.Console.WriteLine($"{Brand} {Model} ({Year})");
        }
    }
}
