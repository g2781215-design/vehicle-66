
using VehicleApp.Models;

namespace VehicleApp.Models
{
    public class Car : Vehicle
    {
        private int Doors;
        private string Transmission;

        public Car(string brand, string model, int year, int doors, string transmission)
            : base(brand, model, year)
        {
            Doors = doors;
            Transmission = transmission;
        }

        public override void Info()
        {
            System.Console.Write("Автокөлік: ");
            base.Info();
            System.Console.WriteLine($"Есік саны: {Doors}, Беріліс қорабы: {Transmission}");
        }
    }
}
