
using VehicleApp.Models;

namespace VehicleApp.Models
{
    public class Motorcycle : Vehicle
    {
        private string BodyType;
        private bool HasBox;

        public Motorcycle(string brand, string model, int year, string bodyType, bool hasBox)
            : base(brand, model, year)
        {
            BodyType = bodyType;
            HasBox = hasBox;
        }

        public override void Info()
        {
            System.Console.Write("Мотоцикл: ");
            base.Info();
            System.Console.WriteLine($"Түрі: {BodyType}, Жүк салғыш: {(HasBox ? "бар" : "жоқ")}");
        }
    }
}
