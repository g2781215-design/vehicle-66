
using VehicleApp.Models;
using VehicleApp.Services;

class Program
{
    static void Main()
    {
        var car1 = new Car("Toyota", "Camry", 2020, 4, "Автомат");
        var moto1 = new Motorcycle("Yamaha", "R1", 2019, "Спорт", true);

        var garage1 = new Garage();
        garage1.AddVehicle(car1);
        garage1.AddVehicle(moto1);

        var fleet = new Fleet();
        fleet.AddGarage(garage1);

        System.Console.WriteLine("\nГараждағы көліктер:");
        fleet.GetGarage(0).ShowVehicles();
    }
}
